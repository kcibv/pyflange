::: pyflange.fatigue
