# pyFlange - python library for large flanges design
# Copyright (C) 2024  KCI The Engineers B.V.,
#                     Siemens Gamesa Renewable Energy B.V.,
#                     Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License, as published by
# the Free Software Foundation, either version 3 of the License, or any
# later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License version 3 for more details.
#
# You should have received a copy of the GNU General Public License
# version 3 along with this program.  If not, see <https://www.gnu.org/licenses/>.

'''Mechanical models of single-bolt flange segments.

This module contains `FlangeSegment` classes, which model the mechanical
behavior of a flange sector containing one bolt only. The module provides:

- `Gap`: description of the imperfection gap between two flange faces.
- `FlangeSegment`: abstract base class defining the transfer-function interface
  (bolt axial force and bolt bending moment as functions of the shell pull force).
- `PolynomialFlangeSegment`: abstract base class implementing the polynomial
  transfer functions of refs. [1] and [2].
- `PolynomialLFlangeSegment` and `PolynomialLFlangeSegmentED2`: polynomial
  L-flange segment models (the latter implementing the modifications expected
  in IEC 61400-6 ED2).
- `PolynomialTFlangeSegment`: polynomial T-flange segment model.
- `bolt_markov_matrix`: conversion of a flange bending-moment Markov matrix into
  a bolt stress Markov matrix, via the segment transfer functions.
- `shell_stiffness`: shell stiffness interpolated from tabulated FEA results.

The only types of FlangeSegment currently available are an L-Flange segment
and a T-Flange segment, implementing a polynomial relation between tower shell
force and bolt force / bolt moment. Nonetheless, this module has been structured
to be easily extensible with other types of FlangeSegment model, such as
Multilinear (Petersen) L-Flanges, Multilinear T-Flanges, etc.

Units:
    All parameters must be supplied in a consistent system of units, e.g. meters
    for lengths, newtons for forces and pascals for stresses. Angles are
    expressed in radians.

Example:
    The following example creates an L-flange segment and evaluates the bolt
    axial force for a given shell pull force.

    ```python
    from math import pi
    from pyflange.bolts import StandardMetricBolt, RoundNut
    from pyflange.flangesegments import Gap, PolynomialLFlangeSegment

    fseg = PolynomialLFlangeSegment(
        a=0.150, b=0.122, s=0.054, t=0.172, R=4.0,
        central_angle=2*pi/156,
        Zg=-115e3,                              # dead weight per bolt (compression)
        bolt=StandardMetricBolt("M80", "10.9", shank_length=0.160, stud=True),
        Fv=2.9e6,                               # bolt preload
        Do=0.086, washer=None, nut=RoundNut("M80"),
        gap=Gap(height=0.002, angle=pi/6))

    Fs = fseg.bolt_axial_force(500e3)           # bolt force for a shell pull of 500 kN
    ```

The models implemented in this module are based on the following references:

- `[1]` Marc Seidel, SGRE TE TF PST: IEC 61400-6 AMD1 Background Document
  Fatigue design for ring flange connections in wind turbine support structures.
- `[2]` IEC 61400-6:2020/AMD1 - Wind energy generation systems - Part 6: Tower and foundation
  design requirements - Amendment 1. Draft version 2024-10-01.
- `[3]` Petersen, C.: Nachweis der Betriebsfestigkeit exzentrisch beanspruchter Ringflansch-verbindungen
  (Fatigue assessment of eccentrically loaded ring flange connections).
  Stahlbau 67 (1998), S. 191-203. <https://onlinelibrary.wiley.com/doi/abs/10.1002/stab.199800690>
- `[4]` Petersen, C.: Stahlbau (Steel construction), 4. Auflage Braunschweig: Wiesbaden: Springer Vieweg 2012.
  <https://link.springer.com/book/10.1007%2F978-3-8348-8610-1>
- `[9]` Tobinaga, I.; Ishihara, T.: A study of action point correction factor for L-type flanges of wind turbine towers.
  Wind Energy 21 (2018), p. 801-806. <https://doi.org/10.1002/we.2193>
'''



from abc import ABC, abstractmethod
from dataclasses import dataclass
from functools import cache, cached_property

from .utils import Logger, log_data
logger = Logger(__name__)

import numpy as np

from .bolts import Bolt, Washer, Nut

from math import pi

import pandas as pd
#from.fatigue import SNCurve



@dataclass
class Gap:
    '''A flange gap due to imperfections.

    Attributes:
        height (float): Maximum longitudinal gap height.
        angle (float): Angle subtended by the gap arc from the flange center,
            in radians.
        shape_factor (float): Factor accounting for a shape different than
            sinusoidal. Defaults to 1.0 (sinusoidal gap).
    '''

    height       : float         # maximum longitudinal gap height
    angle        : float         # angle subtended by the gap arc from the flange center
    shape_factor : float = 1.0   # Factor accounting for a shape different than sinusoidal



class FlangeSegment (ABC):
    '''Abstract base class for a flange segment.

    This class is meant to be extended and not to be instantiated directly.
    Each FlangeSegment child class must implement the two transfer-function
    methods: `.bolt_axial_force(Z)` and `.bolt_bending_moment(Z)`.
    '''

    @abstractmethod
    def bolt_axial_force (self, shell_pull):
        '''Calculates the bolt axial force generated by a shell pull force.

        Args:
            shell_pull (float or numpy.ndarray): The shell pull force Z.

        Returns:
            float or numpy.ndarray: The resulting bolt axial force.
        '''
        pass

    @abstractmethod
    def bolt_bending_moment (self, shell_pull):
        '''Calculates the bolt bending moment generated by a shell pull force.

        Args:
            shell_pull (float or numpy.ndarray): The shell pull force Z.

        Returns:
            float or numpy.ndarray: The resulting bolt bending moment.
        '''
        pass



class PolynomialFlangeSegment (FlangeSegment):
    '''A generic FlangeSegment with polynomial transfer functions.

    This class implements a polynomial relation between tower shell force Z and
    bolt axial force Fs or bolt bending moment Ms. It is not meant to be
    instantiated directly but to be subclassed.

    The polynomial transfer functions are defined by 4 reference points:

    - P1: Flange segment at rest.
    - P2: Flange segment at ultimate tensile limit state.
    - P3: Flange segment in small tensile deformation.
    - P4: Gap closure state.

    Child classes must provide the coordinates of these points (shell force,
    bolt force and bolt moment) through the abstract properties of this class.
    The transfer functions are a quadratic polynomial through P1, P2 and P3 in
    the tensile domain (above the shell force at rest), a quadratic polynomial
    between P4 and P1 in the compressive domain, and a constant below P4.
    '''

    def bolt_axial_force (self, shell_pull):
        '''Calculates bolt axial force from tower shell force using a polynomial.

        The relation is defined as a polynomial function based on ref. [1],
        section 8.2 and ref. [2], section G.4.2.

        Args:
            shell_pull (float or numpy.ndarray): The tower shell force Z.

        Returns:
            float or numpy.ndarray: The corresponding bolt axial force Fs.
        '''

        # Retrueve the polynomial branch in the tensile domain and the
        # polynomial branch in the compressive domain. The evaluation
        # of both polynomials is delegated to a separate getter for
        # the sake of separation of concerns and code readability.
        tens_poli = self._tensile_force_polynomial
        comp_poli = self._compressive_force_polynomial

        # The tensile polynomial is defined between Z1 and Z2, while
        # the compressive prolynomila between Zmin and Z1
        Z1, Z2 = tens_poli.domain
        Zmin = comp_poli.domain[0]

        # Calculate a vector with the same size as shell_pull, having the Fs value
        # in tensile domain where shell_value is greater than Z1 and 0 in all
        # the other cases.
        Fs_tens = tens_poli(shell_pull) * (shell_pull > Z1)

        # Calculate a vector with the same size as shell_pull, having the Fs value
        # in compressive domain where shell_value is between Zmin and Z1 and 0 in all
        # the other cases.
        Fs_comp = comp_poli(shell_pull) * (shell_pull > Zmin) * (shell_pull <= Z1)

        # Calculate a vector with the same size as shell_pull, having the Fs(Zmin)
        # value where shell_value is lower than or equal to zmin and 0 in all
        # the other cases.
        Fs_min  = comp_poli(Zmin) * (shell_pull <= Zmin)

        # Compose the three branches together and return them.
        return Fs_tens + Fs_comp + Fs_min


    def bolt_bending_moment (self, shell_pull):
        '''Calculates bolt bending moment from tower shell force using a polynomial.

        The relation is defined as a polynomial function based on ref. [1],
        section 8.3 and ref. [2], section G.4.2.

        Args:
            shell_pull (float or numpy.ndarray): The tower shell force Z.

        Returns:
            float or numpy.ndarray: The corresponding bolt bending moment Ms.
        '''

        # Retrueve the polynomial branch in the tensile domain and the
        # polynomial branch in the compressive domain. The evaluation
        # of both polynomials is delegated to a separate getter for
        # the sake of separation of concerns and code readability.
        tens_poli = self._tensile_moment_polynomial
        comp_poli = self._compressive_moment_polynomial

        # The tensile polynomial is defined between Z1 and Z2, while
        # the compressive prolynomila between Zmin and Z1
        Z1, Z2 = tens_poli.domain
        Zmin = comp_poli.domain[0]

        # Calculate a vector with the same size as shell_pull, having the Ms values
        # in tensile domain where shell_value is greater than Z1 and 0 in all
        # the other cases.
        Ms_tens = tens_poli(shell_pull) * (shell_pull > Z1)

        # Calculate a vector with the same size as shell_pull, having the Ms values
        # in compressive domain where shell_value is between Zmin and Z1 and 0 in all
        # the other cases.
        Ms_comp = comp_poli(shell_pull) * (shell_pull > Zmin) * (shell_pull <= Z1)

        # Calculate a vector with the same size as shell_pull, having the Ms(Zmin)
        # value where shell_value is lower than or equal to zmin and 0 in all
        # the other cases.
        Ms_min  = comp_poli(Zmin) * (shell_pull <= Zmin)

        # Compose the three branches together and return them.
        return Ms_tens + Ms_comp + Ms_min


    @cached_property
    def _tensile_force_polynomial (self):
        '''Polynomial Fs(Z) for the tensile domain.

        This getter returns the polynomial Fs(Z) defined by refs. [1] and [2]
        between point 1 (flange segment at rest) and point 2 (ultimate
        tensile limit state of the bolt).

        Returns:
            numpy.polynomial.polynomial.Polynomial: The polynomial for the tensile domain.
        '''

        from numpy.polynomial.polynomial import Polynomial
        from numpy.linalg import inv

        # The polynomial function Fs(Z) passes through the following points
        # The point getters are implementation-specific and they should be
        # defined by the child class (L-Flange class or T-Flange class).
        Z1 = self.shell_force_at_rest
        Fs1 = self.bolt_force_at_rest

        Z2 = self.shell_force_at_tensile_ULS
        Fs2 = self.bolt_force_at_tensile_ULS

        Z3 = self.shell_force_at_small_displacement
        Fs3 = self.bolt_force_at_small_displacement

        # The three fitting conditions Fs(Z1)=Fs1, Fs(Z2)=Fs2 and Fs(Z3)=Fs3
        # are written in matrix form as: Z*A=F whenre A is the coefficients
        # vector and F and Z are defined below:
        F = np.array([Fs1, Fs2, Fs3])
        Z = np.array([
            [1, Z1, Z1**2],
            [1, Z2, Z2**2],
            [1, Z3, Z3**2]])

        # The coefficients are therefore:
        a0, a1, a2 = inv(Z) @ F

        # Create and return the polynomial for the tensile domain [Z1, Z2]
        return Polynomial(
            (a0, a1, a2),       # coefficients
            domain=(Z1, Z2),    # the polynomial is defined between Z1 and Z2
            window=(Z1, Z2),
            symbol="Z")         # used to render the independent variable in serializations


    @cached_property
    def _compressive_force_polynomial (self):
        '''Polynomial Fs(Z) for the compressive domain.

        This getter returns the polynomial Fs(Z) defined by refs. [1] and [2]
        between point 1 (flange segment at rest) and point 4 (gap closed).

        Returns:
            numpy.polynomial.polynomial.Polynomial: The polynomial for the compressive domain.
        '''

        from numpy.polynomial.polynomial import Polynomial

        # Retrieve origin of the compressive polynomial
        Z1 = self.shell_force_at_rest
        Fs1 = self.bolt_force_at_rest

        # Retrieve slope of the compressive polynomial at point (Z1, Fs1)
        dtp = self._tensile_force_polynomial.deriv()    # first derivative of the tensile polynomial
        X1 = dtp(Z1)                                    # slope of the tensile polinomial at Z=Z1

        # Value of Z below which the compressive polynomial
        # becomes practically constant
        Zmin = self.shell_force_at_closed_gap

        # Compressive polynomial coefficients
        c2 = 0.5 * X1 / (Z1 - Zmin)
        c1 = X1 - 2*c2*Z1
        c0 = Fs1 - c1*Z1 - c2*Z1**2

        # Create and return the polynomial for the tensile domain [Zmin, Z1]
        return Polynomial(
            (c0, c1, c2),       # coefficients
            domain=(Zmin, Z1),  # the polynomial is defined between Zmin and Z1
            window=(Zmin, Z1),
            symbol="Z")         # used to render the independent variable in serializations


    @cached_property
    def _tensile_moment_polynomial (self):
        '''Polynomial Ms(Z) for the tensile domain.

        This getter returns the polynomial Ms(Z) defined by refs. [1] and [2]
        between point 1 (flange segment at rest) and point 2 (ultimate
        tensile limit state of the bolt).

        Returns:
            numpy.polynomial.polynomial.Polynomial: The polynomial for the tensile domain.
        '''

        from numpy.polynomial.polynomial import Polynomial
        from numpy.linalg import inv

        # The polynomial function Fs(Z) passes through the following points
        # The point getters are implementation-specific and they should be
        # defined by the child class (L-Flange class or T-Flange class).
        Z1 = self.shell_force_at_rest
        Ms1 = self.bolt_moment_at_rest

        Z2 = self.shell_force_at_tensile_ULS
        Ms2 = self.bolt_moment_at_tensile_ULS

        Z3 = self.shell_force_at_small_displacement
        Ms3 = self.bolt_moment_at_small_displacement

        # The three fitting conditions Fs(Z1)=Fs1, Fs(Z2)=Fs2 and Fs(Z3)=Fs3
        # are written in matrix form as: Z*A=F whenre A is the coefficients
        # vector and F and Z are defined below:
        M = np.array([Ms1, Ms2, Ms3])
        Z = np.array([
            [1, Z1, Z1**2],
            [1, Z2, Z2**2],
            [1, Z3, Z3**2]])

        # The coefficients are therefore:
        a0, a1, a2 = inv(Z) @ M

        # Create and return the polynomial for the tensile domain [Z1, Z2]
        return Polynomial(
            (a0, a1, a2),       # coefficients
            domain=(Z1, Z2),    # the polynomial is defined between Z1 and Z2
            window=(Z1, Z2),
            symbol="Z")         # used to render the independent variable in serializations


    @cached_property
    def _compressive_moment_polynomial (self):
        '''Polynomial Ms(Z) for the compressive domain.

        This getter returns the polynomial Ms(Z) defined by refs. [1] and [2]
        between point 1 (flange segment at rest) and point 4 (gap closed).

        Returns:
            numpy.polynomial.polynomial.Polynomial: The polynomial for the compressive domain.
        '''

        from numpy.polynomial.polynomial import Polynomial

        # Retrieve origin of the compressive polynomial
        Z1 = self.shell_force_at_rest
        Ms1 = self.bolt_moment_at_rest

        # Retrieve slope of the compressive polynomial at point (Z1, Fs1)
        dtp = self._tensile_moment_polynomial.deriv()    # first derivative of the tensile polynomial
        X1 = dtp(Z1)                                    # slope of the tensile polinomial at Z=Z1

        # Value of Z below which the compressive polynomial
        # becomes practically constant
        Zmin = self.shell_force_at_closed_gap

        # Compressive polynomial coefficients
        c2 = 0.5 * X1 / (Z1 - Zmin)
        c1 = X1 - 2*c2*Z1
        c0 = Ms1 - c1*Z1 - c2*Z1**2

        # Create and return the polynomial for the tensile domain [Zmin, Z1]
        return Polynomial(
            (c0, c1, c2),       # coefficients
            domain=(Zmin, Z1),  # the polynomial is defined between Zmin and Z1
            window=(Zmin, Z1),
            symbol="Z")         # used to render the independent variable in serializations


    @property
    @abstractmethod
    def shell_force_at_rest (self):
        '''Shell force when no external loads are applied (Z1).'''
        pass


    @property
    @abstractmethod
    def bolt_force_at_rest (self):
        '''Bolt axial force when no external loads are applied (Fs1).'''
        pass


    @property
    @abstractmethod
    def bolt_moment_at_rest (self):
        '''Bolt bending moment when no external loads are applied (Ms1).'''
        pass


    @property
    @abstractmethod
    def shell_force_at_small_displacement (self):
        '''Intermediate tower shell force (Z3).'''
        pass


    @property
    @abstractmethod
    def bolt_force_at_small_displacement (self):
        '''Intermediate bolt axial force (Fs3).'''
        pass


    @property
    @abstractmethod
    def bolt_moment_at_small_displacement (self):
        '''Intermediate bolt bending moment (Ms3).'''
        pass


    @property
    @abstractmethod
    def shell_force_at_tensile_ULS (self):
        '''Ultimate Limit State tower shell force (Z2).'''
        pass


    @property
    @abstractmethod
    def bolt_force_at_tensile_ULS (self):
        '''Bolt axial force at tensile failure (Fs2).'''
        pass


    @property
    @abstractmethod
    def bolt_moment_at_tensile_ULS (self):
        '''Bolt bending moment at tensile failure (Ms2).'''
        pass


    @property
    @abstractmethod
    def shell_force_at_closed_gap (self):
        '''Shell force necessary to completely close the imperfection gap (Z4).'''
        pass



@dataclass
class PolynomialLFlangeSegment (PolynomialFlangeSegment):
    '''An L-Flange implementation of a `PolynomialFlangeSegment`.

    This class models an L-flange segment using the polynomial model from
    ref. [1] and [2]. It defines the reference points for the polynomial
    functions inherited from the parent class.

    The transfer functions are available through the `bolt_axial_force` and
    `bolt_bending_moment` methods, which accept either a scalar or a NumPy
    array of shell pull forces.

    Attributes:
        a (float): Distance from inner flange face to bolt hole center.
        b (float): Distance from bolt hole center to shell center-line.
        s (float): Shell thickness.
        t (float): Flange thickness.
        R (float): Shell outer curvature radius.
        central_angle (float): Angle subtended by the flange segment arc.
        Zg (float): Load on the shell at rest (e.g., dead weight). Negative for compression.
        bolt (Bolt): The bolt in the flange segment.
        Fv (float): Design preload value before losses.
        Do (float): Bolt hole diameter.
        washer (Washer): The washer used. None if no washer.
        nut (Nut): The nut used.
        gap (Gap): The flange gap.
        tilt_angle (float): Flange tilt angle in radians.
        E (float): Young's modulus of the flange material.
        G (float): Shear modulus of the flange material.
        s_ratio (float): Ratio of bottom shell thickness to `s`.
        r (float): Radius of the rounding between shell and flange.
        k_shell (float, callable, None): Shell stiffness [N/m/m]. Can be a value, a
            function taking the flange segment as argument and returning the
            stiffness, or `None` to use the simplified formula of ref. [1].
        PPL (float): Percentage of bolt pretension loss due to plastic strain,
            expressed as a fraction of `Fv` (e.g. 0.03 for 3%). Defaults to 0.0.
        DFT (float): Maximum allowable dry film thickness of coating applied on the contact
            area between washers and flange [m]. Defaults to 0.0 m.
        settlement_factor (float): Factor reducing the amount of bolt settlement, to be
            taken as 1.0 for torque tightening and 0.5 for tension tightening. Defaults to 1.0.
    '''

    a: float        # distance between inner face of the flange and center of the bolt hole
    b: float        # distance between center of the bolt hole and center-line of the shell
    s: float        # shell thickness
    t: float        # flange thickness
    R: float        # shell outer curvature radius
    central_angle: float     # angle subtended by the flange segment

    Zg: float       # load applied to the flange segment shell at rest (normally dead weight
                    # of tower + RNA, divided by the number of bolts). Negative if compression.

    bolt: Bolt      # Bolt object representing the flange segment bolt
    Fv: float       # applied bolt preload before pretension losses

    Do: float       # Bolt hole diameter
    washer: Washer  # Bolt washer
    nut: Nut        # Bolt nut

    gap: Gap        # Object representing the flange gap

    tilt_angle: float = 0.0         # angle of flange tilt

    E: float = 210e9        # Young modulus of the flange
    G: float = 80.77e9      # Shear modulus of the flange
    s_ratio: float = 1.0    # Ratio of bottom shell thickness over s. Default s_botom = s.
    r: float = 0.01         # Rounding between flange and shell
    
    k_shell: float = None       # optional initial shell stiffness in [N/m/m].

    PPL: float = 0.0      # Percentage of pretension losses due to plastic strain

    DFT: float = 0.0        # Maximum allowable dry film thickness of coatings applied in the 
                            # contact area between washers and flange [m]

    settlement_factor: float = 1.0   # Factor reducing the amount of bolt settlement, to be
                                     # taken as 1.0 for torque tightening and 1.0 for tension tightening.


    def failure_mode (self, fy_sh, fy_fl, gamma_0=1.1):
        '''Determines the failure mode of the flange.

        The ultimate shell force is evaluated for each of the failure modes
        A, B, D and E of ref. [2], and the governing mode is the one with the
        lowest ultimate shell force.

        Args:
            fy_sh (float): Yield stress of the shell material.
            fy_fl (float): Yield stress of the flange material.
            gamma_0 (float, optional): Material factor. Defaults to 1.1.

        Returns:
            tuple: A tuple containing:

                - str: The failure mode ("A", "B", "D", or "E").
                - list: A list of the shell force limits for each failure mode [Zu_A, Zu_B, Zu_D, Zu_E].
        '''

        from scipy.optimize import fsolve

        fd_sh = fy_sh / gamma_0
        fd_fl = fy_fl / gamma_0
        
        Dw = self.washer.outer_diameter if self.washer else self.nut.bearing_diameter
        b_red = self.b-self.s/2-0.8*self.r

        c_shell = self.central_angle * (self.R - self.s/2)
        c_hole = self.central_angle * (self.R - self.s/2 - self.b) - self.bolt.nominal_diameter
        c_washer = self.central_angle * (self.R - self.s/2 - self.b + (self.Do/2 + Dw/2)/2)

        # Failure mode A
        F_tRd = self.bolt.ultimate_tensile_capacity()   # Bolt ultimate tensile capacity
        Zu_A = F_tRd                                    # Ultimate tower shell force for failure mode A

        # Shell cross-section ultimate capacities
        Nu_sh = fd_sh * c_shell * self.s                 # Pure axial ultimate capacity
        Mu_sh = fd_sh * c_shell * self.s**2 / 4          # Pure bending ultimate capacity
        MNu_sh = lambda N: Mu_sh * (1 - (N / Nu_sh)**2) if N < Nu_sh else 0 # Bending ultimate capacity, concurrent with axial force

        # Flange cross-section ultimate capacity (at hole)
        Vu_fl = fd_fl * c_washer * self.t / 3**0.5                # Pure shear ultimate capacity
        Mu_fl = fd_fl * c_washer * self.t**2 / 4                  # Pure bending ultimate capacity
        MVu_fl = lambda V: Mu_fl * (1 - (V / Vu_fl)**2)**0.5 if V < Vu_fl else 0    # Bending ultimate capacity, concurrent with shear

        # Iterative calculation of the ultimate shell force, given the two functions:
        # - Zu_sh(Mu_pl3), returning the shell force at shell axial ULS, for a given value of Mu_pl3
        # - Zu_fl(Mu_pl3), returning the shell force at slange shear ULS, for a given value of Mu_pl3
        # Ref. [2], eq. G.11.
        def find_Zu (Zu_sh, Zu_fl):
            target_Zu_sh = fsolve(lambda Z: Zu_sh(MNu_sh(Z)) - Z, Zu_sh(Mu_sh))[0]
            target_Zu_fl = fsolve(lambda Z: Zu_fl(MVu_fl(Z)) - Z, Zu_fl(Mu_fl))[0]
            return min(target_Zu_sh, target_Zu_fl)

        # Failure mode B
        Zu_sh_B = lambda Mu_pl3: (F_tRd * self._a_red + Mu_pl3) / (self._a_red + self.b)
        Zu_fl_B = lambda Mu_pl3: (F_tRd * self._a_red + Mu_pl3) / (self._a_red + b_red)
        Zu_B = find_Zu(Zu_sh_B, Zu_fl_B) 

        # Failure mode D
        Mu_pl2 = fd_fl * c_hole * self.t**2 / 4
        DMu_pl2 = F_tRd/2 * (self.Do/2 + Dw/2)/2
        Zu_sh_D = lambda Mu_pl3: (Mu_pl2 + DMu_pl2 + Mu_pl3) / self.b
        Zu_fl_D = lambda Mu_pl3: (Mu_pl2 + DMu_pl2 + Mu_pl3) / b_red
        Zu_D = find_Zu(Zu_sh_D, Zu_fl_D) 

        # Failure mode E
        b_E = self.b - (self.Do+Dw)/4
        b_E_red = b_E - self.s/2 - 0.8*self.r
        Zu_sh_E = lambda Mu_pl3: (Mu_fl + Mu_pl3) / b_E
        Zu_fl_E = lambda Mu_pl3: (Mu_fl + Mu_pl3) / b_E_red
        Zu_E = find_Zu(Zu_sh_E, Zu_fl_E) 

        # Determine the governing failure mode
        Zu_min = min(Zu_A, Zu_B, Zu_D, Zu_E)

        if Zu_min == Zu_A:
            return "A",[Zu_A, Zu_B, Zu_D, Zu_E]
        elif Zu_min == Zu_B:
            return "B",[Zu_A, Zu_B, Zu_D, Zu_E]
        elif Zu_min == Zu_D:
            return "D",[Zu_A, Zu_B, Zu_D, Zu_E]
        elif Zu_min == Zu_E:
            return "E",[Zu_A, Zu_B, Zu_D, Zu_E]


    def validate (self, fy_sh, fy_fl, gamma_0=1.1):
        '''Verifies the applicability of the polynomial model.

        Checks if this L-Flange Segment fails according to failure mode B.

        Args:
            fy_sh (float): Yield stress of the shell material.
            fy_fl (float): Yield stress of the flange material.
            gamma_0 (float, optional): Material factor. Defaults to 1.1.

        Raises:
            ValueError: If the failure mode is not "B".
        '''

        failure_mode, failure_shellforces = self.failure_mode(fy_sh, fy_fl, gamma_0=gamma_0)

        if failure_mode != "B":
            raise ValueError(f"Failure mode {failure_mode} detected, while only failure mode B is supported.")


    @cached_property
    def _bolt_axial_stiffness (self):
        '''The axial stiffness of the bolt.'''
        tw = self.washer.thickness if self.washer else 0
        return self.bolt.axial_stiffness(2*self.t + 2*tw)


    @cached_property
    def _bolt_bending_stiffness (self):
        '''The bending stiffness of the bolt.'''
        tw = self.washer.thickness if self.washer else 0
        return self.bolt.bending_stiffness(2*self.t + 2*tw)


    @cached_property
    def _flange_axial_stiffness (self):
        '''The axial stiffness of the flange in the thickness direction.'''
        # Stiffnes of flange w.r.t. compression in thickness direction,
        # when no gap is present. Calculated according to ref. [3] and [4].
        from math import pi, inf
        Dw = self.washer.outer_diameter if self.washer else self.nut.bearing_diameter
        Do = self.Do
        h = self.t * 2
        A = pi * ((Dw + h/10)**2 - Do**2) / 4
        Kf = self.E * A / h
        Kw = self.washer.axial_stiffness if self.washer else inf
        return 1 / (1/Kf + 2 * 1/Kw)


    def _bolt_moment (self, Z, Fs):
        '''Calculates the bolt bending moment.

        Args:
            Z (float): Shell pull force.
            Fs (float): Bolt axial force.

        Returns:
            float: The bolt bending moment.
        '''
        s_avg = self.s * (1 + self.s_ratio) / 2
        c = self.central_angle * (self.R - s_avg/2)
        I_tg = c * self.t**3 / 12
        ak = self._stiffness_correction_factor
        bolt_rotation = Z*self.b*self._a_star / (3*self.E*I_tg*ak) + (Fs - self.bolt_preload) / (2*self._a_star*self._bolt_axial_stiffness)

        log_data(self, I_tg=I_tg)

        return bolt_rotation * 2*self._bolt_bending_stiffness


    @cached_property
    def bolt_preload (self):
        '''float: Bolt preload after settlement and plastic losses.

        The preload `Fv` is reduced by the settlement loss (function of `DFT`
        and `settlement_factor`) and by the plastic loss (`PPL * Fv`).
        '''
        from metrum.units import um, kN

        # Preload losses due to settlements
        if self.DFT > 0:
            DFT_ref = 1*um
            f_z_tot = max( (8*(self.DFT/DFT_ref)**(-0.6))*self.DFT , 50*um )
            bolt_resilience = 1 / self._bolt_axial_stiffness
            flange_resilience = 1 / self._flange_axial_stiffness
            delta_Fv_z = self.settlement_factor * (f_z_tot / (bolt_resilience + flange_resilience))
        else:
            delta_Fv_z = 0*kN

        # Preload losses due to plastic deformation
        delta_Fv_pl = self.PPL * self.Fv

        return self.Fv - delta_Fv_z - delta_Fv_pl


    @cached_property
    def shell_force_at_rest (self):
        '''Shell force when no external loads are applied (Z1).

        The shell loads at rest are normally the self-weights of
        the structure supported by the flange.
        '''
        return self.Zg


    @cached_property
    def bolt_force_at_rest (self):
        '''Bolt axial force when no external loads are applied (Fs1).

        The bolt force at rest is just the bolt pretension.
        '''
        return self.bolt_preload


    @cached_property
    def bolt_moment_at_rest (self):
        '''Bolt bending moment when no external loads are applied (Ms1).'''

        Z1 = self.shell_force_at_rest
        Fs1 = self.bolt_force_at_rest
        return self._bolt_moment(Z1, Fs1)


    @cached_property
    def shell_force_at_small_displacement (self):
        '''Intermediate tower shell force (Z3).

        This auxiliary point gives the polynomial the right initial slope,
        evaluated according to ref. [1], sec. 8.2.2.3 and ref. [2], sec. G.4.2.
        '''

        # Retrieve point 2A (called point 0 in [1]) and determine Z as
        # a low pecentage of the theoretical pull Z0.
        Z0 = self._ideal_shell_force_at_tensile_ULS
        return 0.05 * self._stiffness_correction_factor * Z0


    @cached_property
    def bolt_force_at_small_displacement (self):
        '''Intermediate bolt axial force (Fs3).

        This auxiliary point gives the polynomial the right initial slope,
        evaluated according to ref. [1], sec. 8.2.2.3 and ref. [2], sec. G.4.2.
        '''

        # The slope between points P1 and P3 should match the
        # theoretical value of stiffness of the system.
        Z = self.shell_force_at_small_displacement
        return self.bolt_preload + self._polynomial_initial_slope * (Z - self.Zg)


    @cached_property
    def bolt_moment_at_small_displacement (self):
        '''Intermediate bolt bending moment (Ms3).'''

        Z3 = self.shell_force_at_small_displacement
        Fs3 = self.bolt_force_at_small_displacement
        return self._bolt_moment(Z3, Fs3)


    @cached_property
    def shell_force_at_tensile_ULS (self):
        '''Ultimate Limit State tower shell force (Z2).

        This is the tower shell force that brings the flange segment to its
        tensile ULS, evaluated according to ref. [1], sec. 8.2.2.2 and
        ref. [2], sec. G.4.2.
        '''

        Z0 = self._ideal_shell_force_at_tensile_ULS
        Z2 = self._stiffness_correction_factor * max(
            Z0 + self._total_gap_neutralization_shell_force,
            0.2 * Z0)
        return min(Z0, Z2)


    @cached_property
    def bolt_force_at_tensile_ULS (self):
        '''Bolt axial force at tensile failure (Fs2).

        This is the bolt's tensile force at the shell's ULS, assuming
        failure mode B.
        '''

        # Bolt force at tensile ULS for sinusoidal gap shape
        Fs2 = self._ideal_bolt_force_at_tensile_ULS

        # Scale Fs2 based on the gap shape
        Fs1 = self.bolt_force_at_rest
        return Fs1 + (Fs2 - Fs1) * self.gap.shape_factor


    @cached_property
    def bolt_moment_at_tensile_ULS (self):
        '''Bolt bending moment at tensile failure (Ms2).'''

        Z2 = self.shell_force_at_tensile_ULS
        Fs2 = self.bolt_force_at_tensile_ULS
        return self._bolt_moment(Z2, Fs2)


    @cached_property
    def shell_force_at_closed_gap (self):
        '''Shell force necessary to completely close the imperfection gap (Z4).'''
        return self.shell_force_at_rest + self._total_gap_neutralization_shell_force

    @cached_property
    def _a_red (self):
        #Tobinaga reduction
        return self.b / (self._prying_lever_ratio - 1)

    @cached_property
    def _a_star (self):
        return max(0.4, min((self.t / (self._a_red + self.b))**2 , 1)) * self._a_red

    @cached_property
    def _total_gap_neutralization_shell_force (self):
        '''Incremental force to close the imperfection gap (delta-Z_gap,total).'''
        MAXIMUM_GAP_NEUTRALIZATION_SHELL_FORCE = -1000 # 1 kN
        return min(self._parallel_gap_neutralization_shell_force - self._tilt_neutralization_shell_force,
                   MAXIMUM_GAP_NEUTRALIZATION_SHELL_FORCE)


    @cached_property
    def _parallel_gap_neutralization_shell_force (self):
        '''Force necessary to close a parallel imperfection gap.'''
        s_avg = self.s * (1 + self.s_ratio) / 2
        c = self.central_angle * (self.R - s_avg/2)
        return -0.5 * self._gap_stiffness * self.gap.height * c


    @cached_property
    def _tilt_neutralization_shell_force (self):
        '''Force that neutralizes the flange tilt (DZ_gap,incl).

        This solves equation (G.64) of ref. [2].
        '''

        # The equation to be solved is A*[inv(B)*C]*M = D,
        # where A and B are 2x2 matrices, C and D are 2x1 matrices
        # and M is the scalar to be determined

        # General parameters
        s_mean = self.s * (1+self.s_ratio)/2
        w = self.a + self.b + self.s/2
        Af = w * self.t
        If = w * self.t**3 / 12
        R_sh = self.R - s_mean/2
        R_fl = self.R - w/2
        nu = self.E / (2*self.G) - 1
        k = self.E * s_mean**3 / (12*(1-nu**2))
        n = (3*(1-nu**2))**0.25 / (R_sh * s_mean)**0.5

        # Matrix A
        a11 = 1 / (2*k*n**3)
        a12 = 1 / (2*k*n**2)
        a21 = a12
        a22 = 1 / (k*n)
        A = np.array([[a11, a12],
                    [a21, a22]])

        # Matrix B
        b11 = a11 + R_fl * R_sh / (self.E * Af)
        b12 = a12
        b21 = a12
        b22 = a22 + R_fl * R_sh / (self.E * If)
        B = np.array([[b11, b12],
                    [b21, b22]])

        # Matrix C
        c1 = 0
        c2 = R_fl**2 / (self.E * If)
        C = np.array([c1, c2])

        # Matrix D
        d1 = 0.001    # ux: dummy value, sice irrelevant
        d2 = self.tilt_angle
        D = np.array([d1, d2])

        # Reduce matrix equation to H*M = D
        H = A @ (np.linalg.inv(B) @ C)

        # The last equation of the system H*M = D is h2*M = d2 and
        # we can therefore determine M from it as d2/h2:https://kcibv-my.sharepoint.com/:x:/g/personal/g_arona_kci_nl/IQAKaieb_blBTKSeQD2YdipAAapxRzwqZ_nRcG577qOwY-I?e=l8iviI
        M = d2 / H[1]

        # Return the tower shell force force corresponding to M
        c = self.central_angle * R_sh
        b_mean = self.b + self.s/2 - s_mean/2
        return -c * M / (s_mean/2 + b_mean)

    
    @cached_property
    def _ideal_bolt_force_at_tensile_ULS (self):
        '''Bolt axial force at tensile failure for a sinusoidal gap shape.'''
        return max(self.bolt.ultimate_tensile_capacity(), 1.25*self.bolt_force_at_rest)


    @cached_property
    def _ideal_shell_force_at_tensile_ULS (self):
        '''Tower shell force at the theoretical state of full prying (Z0).'''
        return self._ideal_bolt_force_at_tensile_ULS / self._prying_lever_ratio


    @cached_property
    def _prying_lever_ratio (self):
        '''Lever ratio A, as defined in [9].'''

        # Ref. [9] uses different symbolts than ref. [1].
        # This getter uses the symbols defined in ref. [9].
        e = self.a
        g = self.b

        # The flange is considered rigid if e <= 1.25*g.
        # In a rigid flange, the pivid point is the edge, therefore e_reduced = e.
        if e/g <= 1.25:
            return (e + g) / e

        # For e > 2.25*g, the model defined in ref. [9] has not been
        # validated. A warning is thrown, but then the model is applied
        # anyways.
        if e/g > 2.25:
            logger.warning("Flange geometry out of validity range for Tobinaga & Ishihara lever ratio formulation: e/g > 2.25.")

        # Coefficient a, expressing the slenderness of the longitudinal
        # cross-section of this flange-segment as tatio between thickness
        # and length.
        a = min(self.t / (e+g), 1.0)
        if a < 0.55 - 0.12 * (e/g):
            # When outside the boundary of validations, throw a warning, but then
            # apply the model anyways.
            logger.warning("Flange geometry out of validity range for Tobinaga & Ishihara lever ratio formulation: a < 0.55 - 0.12 * (e/g).")

        # Evaluate the ratio between distance e (pivit point location for rigid body rotation)
        # and the acctual center of reaction at the prying contact location.
        b = (e/g - 1.25)**0.32 + 0.45
        actionpoint_correction_factor = min(1 - (1 - a**b)**5, 1.0)

        # Distance from the center of reaction at prying contact location, form
        # the center of bolt hole.
        e_reduced = actionpoint_correction_factor * e

        # Lever ratio
        return (e_reduced + g) / e_reduced


    @cached_property
    def _k_shell (self):
        # Shell stiffness
        s_avg = (self.s + self.s_ratio * self.s) / 2    # Average shell thickness
        L_gap = self.R * self.gap.angle                 # Gap lenght at mid-line of shell with average thickness
        k_fac = max(1.8, 1.3 + (8.0e-4 - 1.6e-7 * (self.R*1000)) * (L_gap*1000))    # ref. [1], eq.48A
        try:
            k_shell = float(self.k_shell)
        except Exception:
            k_shell = self.k_shell(self) if callable(self.k_shell) else self.E * s_avg / (k_fac * L_gap)

        log_data(self, L_gap=L_gap, k_fac=k_fac)
        return k_shell


    @cached_property
    def _k_flange (self):
        # Calculate the flange stiffness
        L_gap = self.R * self.gap.angle                 # Gap lenght at mid-line of shell with average thickness
        w = self.a + self.b + self.s/2      # flange segment length
        A = w * self.t                      # flange segment longitudinal cross-section area
        I = w * self.t**3 / 12              # flange segment longitudinal corss-section second moment of area
        EI = self.E * I
        GA = self.G * A
        L2 = L_gap**2
        k_flange = 384 * EI * GA / (L2 * (GA*L2 + 48*EI))   # ref. [1], eq.49
        log_data(self, A_cf=A, I_cf=I, k_fl=k_flange)
        return k_flange


    @cached_property
    def _gap_stiffness (self):
        '''Stiffness of the design gap.

        Returns the gap stiffness as a spring constant per unit of flange-segment
        arc length, calculated according to ref.[1], sec. 8.1 and ref.[2], eq. G.35.
        '''

        # Stiffness correction factor
        f_tot = min(1.0 + 1.5 * self.gap.angle/(pi/2), 2.5) * min(self.gap.angle/(pi/6), 1)**2

        log_data(self, f_tot=f_tot)

        # Total gap stiffness according to ref. [1], eq.53
        return f_tot * (self._k_shell + self._k_flange)


    @cached_property
    def _stiffness_correction_factor (self):
        '''Stiffness correction factor (alpha-k).

        This factor modifies the segment force to account for the effect of
        the gap spring, evaluated according to ref. [1], sec. 8.2.2.2 and
        ref. [2], eq. G.46.
        '''

        from math import pi

        # Retrieve point P0
        Z0 = self._ideal_shell_force_at_tensile_ULS
        Fs0 = self._ideal_bolt_force_at_tensile_ULS

        # Evaluate the displacement u in the ultimate prying state.
        s_avg = self.s * (1 + self.s_ratio) / 2
        c = self.central_angle * (self.R - s_avg/2)
        I = c * self.t**3 / 12
        u = (Z0 * self.b**2 / (3 * self.E * I) + (Fs0 - self.bolt_preload) / (2 * self._bolt_axial_stiffness * self._a_red)) * (self._a_red + self.b)   # ref. [1], eq.72

        # Evaluate the segment stiffness
        s_avg = (self.s + self.s_ratio * self.s) / 2
        c = self.central_angle * (self.R - s_avg/2)
        k_seg = Z0 / (u * c)

        log_data(self, u=u, k_seg=k_seg)

        # Return the stiffness correction factor, acc. [1], eq.75
        return min(1 + self._gap_stiffness / k_seg,
                   4 * pi/3 / self.gap.angle)


    @cached_property
    def _polynomial_initial_slope (self):
        '''Initial slope of the Fs(Z) polynomial.

        This slope is calculated according to ref. [1], section 8.2.2.3
        and ref. [2], eq. G.53.
        '''

        # Load factor of the tension spring
        Ks = self._bolt_axial_stiffness
        Kp = self._flange_axial_stiffness
        p = Ks / (Ks + Kp)

        # Initial slope correction factor
        scf = -self._total_gap_neutralization_shell_force / (0.5 * self.bolt_preload)

        # Maximum allowable value of p
        p_max = (self.bolt_force_at_tensile_ULS - self.bolt_force_at_rest) / (self.shell_force_at_tensile_ULS - self.shell_force_at_rest)

        # Initial slope
        return min(scf*p, p_max) * self.gap.shape_factor


    # ----------------------------------------------------------------------
    #  DEPRECATED ATTRIBUTES AND METHODS
    #
    #  The following methods are deprecated and kept only for backwards
    #  compatibility
    # ----------------------------------------------------------------------

    @property
    def gap_height (self):
        '''Deprecated. Use `gap.height` instead.'''
        return self.gap.height

    @property
    def gap_angle (self):
        '''Deprecated. Use `gap.angle` instead.'''
        return self.gap.angle

    @property
    def gap_shape_factor (self):
        '''Deprecated. Use `gap.shape_factor` instead.'''
        return self.gap.shape_factor



class PolynomialLFlangeSegmentED2 (PolynomialLFlangeSegment):
    '''An L-Flange segment modeled as it will be modified in IEC 61400-6 ED2.

    This class has the same parameters and interface as `PolynomialLFlangeSegment`,
    but it replaces the `a*` parameter, the parallel-gap closing force and the
    gap stiffness with the formulations that will be introduced in
    IEC 61400-6 ED2.
    '''
    
    @cached_property
    def _a_star (self):
        ''' a* parameter
        As it will be modified in IEC 61400-6 ED2
        '''
        return max(0.3, min((self.t / (self._a_red + self.b))**2 , 1)) * self._a_red


    @cached_property
    def _parallel_gap_neutralization_shell_force (self):
        '''Force necessary to close a parallel imperfection gap.
        As it will be modified in IEC 61400-6 ED2
        '''

        # Calaculate ED2 correction factor
        d = self.bolt.nominal_diameter
        alfa_ref = 1 - 0.630 * 2*d / (1.25*self.b + self.b)
        It_ref = alfa_ref * (1.25*self.b+self.b) * (2*d)**3 / 3
        alfa = 1 - 0.630 * self.t / (self.a + self.b)
        It = alfa * (self.a + self.b) * self.t**3 / 3
        f_kgap = max(1.0 , min( self.a/self.b / (It/It_ref)**0.5 , 1.5))

        # Return ED2 gap closing force
        return f_kgap * super()._parallel_gap_neutralization_shell_force


    @cached_property
    def _gap_stiffness (self):
        '''Stiffness of the design gap.

        Returns the gap stiffness as a spring constant per unit of flange-segment
        arc length, as it will be modified in IEC 61400-6 ED2
        '''

        # Stiffness correction factor
        f_tot = min(1.4 + 0.6 * self.gap.angle/(pi/2), 2.0) * min(self.gap.angle/(pi/6), 1)**2

        log_data(self, f_tot=f_tot)

        # Total gap stiffness according to ref. [1], eq.53
        return f_tot * self._k_shell + self._k_flange



@dataclass
class PolynomialTFlangeSegment (PolynomialFlangeSegment):
    '''A T-Flange implementation of a `PolynomialFlangeSegment`.

    This class models a T-flange segment using the polynomial model from
    ref. [1] and [2]. It defines the reference points for the polynomial
    functions inherited from the parent class.

    The transfer functions are available through the `bolt_axial_force` and
    `bolt_bending_moment` methods, which accept either a scalar or a NumPy
    array of shell pull forces.

    Attributes:
        a (float): Distance from inner flange face to bolt hole center.
        b (float): Distance from bolt hole center to shell center-line.
        s (float): Shell thickness.
        t (float): Flange thickness.
        R (float): Shell outer curvature radius.
        central_angle (float): Angle subtended by the flange segment arc.
        Zg (float): Load on the shell at rest (e.g., dead weight). Negative for compression.
        bolt (Bolt): The bolt in the flange segment.
        Fv (float): Design preload value.
        Do (float): Bolt hole diameter.
        washer (Washer): The washer used. None if no washer.
        nut (Nut): The nut used.
        gap (Gap): The flange gap.
        tilt_angle (float): Flange tilt angle in radians.
        E (float): Young's modulus of the flange material.
        G (float): Shear modulus of the flange material.
        s_ratio (float): Ratio of bottom shell thickness to `s`.
        r (float): Radius of the rounding between shell and flange.
        k_shell (float, None): Shell stiffness [N/m/m]. Can be a value or `None`
            to use the simplified formula of ref. [1].
    '''

    a: float        # distance between inner face of the flange and center of the bolt hole
    b: float        # distance between center of the bolt hole and center-line of the shell
    s: float        # shell thickness
    t: float        # flange thickness
    R: float        # shell outer curvature radius
    central_angle: float     # angle subtended by the flange segment

    Zg: float       # load applied to the flange segment shell at rest (normally dead weight
                    # of tower + RNA, divided by the number of bolts). Negative if compression.

    bolt: Bolt      # Bolt object representing the flange segment bolt
    Fv: float       # applied bolt preload

    Do: float       # Bolt hole diameter
    washer: Washer  # Bolt washer
    nut: Nut        # Bolt nut

    gap: Gap        # Flange gap object
    
    tilt_angle : float = 0.0    # angle of flange tilt

    E: float = 210e9    # Young modulus of the flange
    G: float = 80.77e9  # Shear modulus of the flange
    s_ratio: float = 1.0    # Ratio of bottom shell thickness over s. Default s_botom = s.

    r: float = 0.01 #rounding between flange and shell
    
    k_shell: float = None   # optional initial shell stiffness in [N/m/m].



    def failure_mode (self, fy_sh, fy_fl,gamma_0 = 1.1):
        '''Determines the failure mode of the flange.

        The ultimate shell force is evaluated for each of the failure modes
        A, B, D and E, and the governing mode is the one with the lowest
        ultimate shell force.

        Args:
            fy_sh (float): Yield stress of the shell material.
            fy_fl (float): Yield stress of the flange material.
            gamma_0 (float, optional): Material factor. Defaults to 1.1.

        Returns:
            tuple: A tuple containing:

                - str: The failure mode ("A", "B", "D", or "E").
                - tuple: The shell force limits for each failure mode (Zu_A, Zu_B, Zu_D, Zu_E).
        '''

        from scipy.optimize import fsolve

        fd_fl = fy_fl / gamma_0
        
        Dw = self.washer.outer_diameter if self.washer else self.nut.bearing_diameter
        a_red = self.b / (self._prying_lever_ratio - 1) #Tobinaga reduction
        b_E = self.b-(self.Do+Dw)/4
        b_red = self.b-self.s/2-0.8*self.r
        
        c_hole = self.central_angle * (self.R - self.s/2 - self.b) - self.bolt.nominal_diameter
        c_washer = self.central_angle * (self.R - self.s/2 - self.b + (self.Do/2 + Dw/2)/2)

        # Failure mode A
        F_tRd = self.bolt.ultimate_tensile_capacity()   # Bolt ultimate tensile capacity
        Zu_A = 2*F_tRd                                    # Ultimate tower shell force for failure mode A

        # Flange cross-section ultimate capacity (at hole)
        Vu_fl = fd_fl * c_washer * self.t / 3**0.5                # Pure shear ultimate capacity
        Mu_fl = fd_fl * c_washer * self.t**2 / 4                  # Pure bending ultimate capacity
        MVu_fl = lambda V: Mu_fl * (1 - (V / Vu_fl)**2)**0.5 if V < Vu_fl else 0    # Bending ultimate capacity, concurrent with shear

        # Failure mode B
        Zu_fl_B = lambda Mu_pl3: (F_tRd * a_red + Mu_pl3) / (a_red + b_red)
        Zu_B = 2 * fsolve(lambda Z: Zu_fl_B(MVu_fl(Z)) - Z, Zu_fl_B(Mu_fl))[0]

        # Failure mode D
        Mu_pl2 = fd_fl * c_hole * self.t**2 / 4
        DMu_pl2 = F_tRd/2 * (self.Do/2 + Dw/2)/2
        Zu_fl_D = lambda Mu_pl3: 2*(Mu_pl2 + DMu_pl2 + Mu_pl3) / b_red
        Zu_D = 2 * fsolve(lambda Z: Zu_fl_D(MVu_fl(Z)) - Z, Zu_fl_D(Mu_fl))[0]

        # Failure mode E
        Zu_fl_E = lambda Mu_pl3: 2*(Mu_fl + Mu_pl3) / b_E
        Zu_E = 2 * fsolve(lambda Z: Zu_fl_E(MVu_fl(Z)) - Z, Zu_fl_E(Mu_fl))[0]

        # Determine the governing failure mode
        Zu_min = min(Zu_A, Zu_B, Zu_D, Zu_E)

        if Zu_min == Zu_A:
            return "A",(Zu_A, Zu_B, Zu_D, Zu_E)
        elif Zu_min == Zu_B:
            return "B",(Zu_A, Zu_B, Zu_D, Zu_E)
        elif Zu_min == Zu_D:
            return "D",(Zu_A, Zu_B, Zu_D, Zu_E)
        elif Zu_min == Zu_E:
            return "E",(Zu_A, Zu_B, Zu_D, Zu_E)

    def validate (self, fy_sh, fy_fl,gamma_0 = 1.1):
        '''Verifies the applicability of the polynomial model.

        Checks if this T-Flange Segment fails according to failure mode A.

        Args:
            fy_sh (float): Yield stress of the shell material.
            fy_fl (float): Yield stress of the flange material.
            gamma_0 (float, optional): Material factor. Defaults to 1.1.

        Raises:
            ValueError: If the failure mode is not "A".
        '''

        failure_mode,failure_shellforces = self.failure_mode(fy_sh, fy_fl,gamma_0=gamma_0)

        if failure_mode != "A":
            raise ValueError(f"Failure mode {failure_mode} detected, while only failure mode A is supported.")


    @cached_property
    def _bolt_axial_stiffness (self):
        '''The axial stiffness of the bolt.'''
        tw = self.washer.thickness if self.washer else 0
        return self.bolt.axial_stiffness(2*self.t + 2*tw)


    @cached_property
    def _bolt_bending_stiffness (self):
        '''The bending stiffness of the bolt.'''
        tw = self.washer.thickness if self.washer else 0
        return self.bolt.bending_stiffness(2*self.t + 2*tw)
    

    @cached_property
    def _flange_axial_stiffness (self):
        '''The axial stiffness of the flange in the thickness direction.'''
        # Stiffnes of flange w.r.t. compression in thickness direction,
        # when no gap is present. Calculated according to ref. [3] and [4].
        from math import pi, inf
        Dw = self.washer.outer_diameter if self.washer else self.nut.bearing_diameter
        Do = self.Do
        h = self.t * 2
        A = pi * ((Dw + h/10)**2 - Do**2) / 4
        Kf = self.E * A / h
        Kw = self.washer.axial_stiffness if self.washer else inf
        return 1 / (1/Kf + 2 * 1/Kw)


    def _bolt_moment (self, Z, Fs):
        '''Calculates the bolt bending moment.

        Args:
            Z (float): Shell pull force.
            Fs (float): Bolt axial force.

        Returns:
            float: The bolt bending moment.
        '''
        a_red = self.b / (self._prying_lever_ratio - 1) #Tobinaga reduction
        a_star = max(0.4, min((self.t / (a_red + self.b))**2 , 1)) * a_red

        s_avg = self.s * (1 + self.s_ratio) / 2
        c = self.central_angle * (self.R - s_avg/2)
        A_tg= c *self.t
        I_tg = c * self.t**3 / 12

        ak = self._stiffness_correction_factor

        phi_T_low=(Fs-self.Fv)*( self.b**2/(2*self.E*I_tg) + 1/(0.85*self.G*A_tg) )
        phi_T_high=Z*( self.b**2/(ak*4*self.E*I_tg) + 1/(0.85*self.G*A_tg) )

        Z0 = self._ideal_shell_force_at_tensile_ULS
        Z_close=self.shell_force_at_closed_gap
        
        bolt_rotation=phi_T_low+(phi_T_high-phi_T_low)/(Z0-Z_close)*(Z-Z_close)

        log_data(self, a_star=a_star)

        return bolt_rotation * 2*self._bolt_bending_stiffness

    @cached_property
    def shell_force_at_rest (self):
        '''Shell force when no external loads are applied (Z1).

        The shell loads at rest are normally the self-weights of
        the structure supported by the flange.
        '''
        return self.Zg

    @cached_property
    def bolt_force_at_rest (self):
        '''Bolt axial force when no external loads are applied (Fs1).

        The bolt force at rest is just the bolt pretension.
        '''
        return self.Fv

    @cached_property
    def bolt_moment_at_rest (self):
        '''Bolt bending moment when no external loads are applied (Ms1).'''
        Z1 = self.shell_force_at_rest
        Fs1 = self.bolt_force_at_rest
        return self._bolt_moment(Z1, Fs1)

    @cached_property
    def shell_force_at_small_displacement (self):
        '''Intermediate tower shell force (Z3).

        This auxiliary point gives the polynomial the right initial slope,
        evaluated according to ref. [1], sec. 8.2.2.3 and ref. [2], sec. G.4.2.
        '''
        # Retrieve point 2A (called point 0 in [1]) and determine Z as
        # a low pecentage of the theoretical pull Z0.
        Z0 = self._ideal_shell_force_at_tensile_ULS
        return 0.05 * self._stiffness_correction_factor * Z0

    @cached_property
    def bolt_force_at_small_displacement (self):
        '''Intermediate bolt axial force (Fs3).

        This auxiliary point gives the polynomial the right initial slope,
        evaluated according to ref. [1], sec. 8.2.2.3 and ref. [2], sec. G.4.2.
        '''
        # The slope between points P1 and P3 should match the
        # theoretical value of stiffness of the system.
        Z = self.shell_force_at_small_displacement
        Fs3 = self.Fv + self._polynomial_initial_slope * (Z - self.Zg)

        # Scale Fs3 based on the gap shape
        Fs1 = self.bolt_force_at_rest
        return Fs1 + (Fs3 - Fs1)

    @cached_property
    def bolt_moment_at_small_displacement (self):
        '''Intermediate bolt bending moment (Ms3).'''
        Z3 = self.shell_force_at_small_displacement
        Fs3 = self.bolt_force_at_small_displacement
        return self._bolt_moment(Z3, Fs3)

    @cached_property
    def shell_force_at_tensile_ULS (self):
        '''Ultimate Limit State tower shell force (Z2).

        This is the tower shell force that brings the flange segment to its
        tensile ULS, evaluated according to ref. [1], sec. 8.2.2.2 and
        ref. [2], sec. G.4.2.
        '''
        Z0 = self._ideal_shell_force_at_tensile_ULS
        Z2 = self._stiffness_correction_factor * max(
            Z0 + self._total_gap_neutralization_shell_force,
            0.2 * Z0)
        return min(Z0, Z2)
    
    @cached_property
    def bolt_force_at_tensile_ULS (self):
        '''Bolt axial force at tensile failure (Fs2).

        This is the bolt's tensile force at the shell's ULS, assuming
        failure mode A.
        '''
        # Bolt force at tensile ULS for sinusoidal gap shape
        Fs2 = self._ideal_bolt_force_at_tensile_ULS

        # Scale Fs2 based on the gap shape
        Fs1 = self.bolt_force_at_rest
        return Fs1 + (Fs2 - Fs1) * self.gap.shape_factor

    @cached_property
    def bolt_moment_at_tensile_ULS (self):
        '''Bolt bending moment at tensile failure (Ms2).'''
        Z2 = self.shell_force_at_tensile_ULS
        Fs2 = self.bolt_force_at_tensile_ULS
        return self._bolt_moment(Z2, Fs2)

    @cached_property
    def shell_force_at_closed_gap (self):
        '''Shell force necessary to completely close the imperfection gap (Z4).'''
        return self.shell_force_at_rest + self._total_gap_neutralization_shell_force

    @cached_property
    def _total_gap_neutralization_shell_force (self):
        '''Total incremental force to close the imperfection gap.'''
        delta_Z_gap=self._parallel_gap_neutralization_shell_force
        delta_Z_gap_c=self._tilt_neutralization_shell_force
        delta_Z_gap_incl=self._early_prying_neutralization_shell_force
        
        #total shell force at closed gap
        delta_Z_gap_tot=delta_Z_gap+delta_Z_gap_c+delta_Z_gap_incl

        return delta_Z_gap_tot
    
    @cached_property
    def _parallel_gap_neutralization_shell_force (self):
        '''Force necessary to close a parallel imperfection gap.'''
        s_avg = self.s * (1 + self.s_ratio) / 2
        c = self.central_angle * (self.R - s_avg/2)
        return -0.5 * self._gap_stiffness * self.gap.height * c
    
    @cached_property
    def _tilt_neutralization_shell_force (self):
        '''Force that neutralizes the flange tilt.'''
        # Calculate geometric properties               
        Rm= self.R - self.s/2
        c_m=self.central_angle*Rm
        w=2*(self.a+self.b)

        #Reduction due to inclination (58)
        #shell parameters (56) & (57)
        K=self.E*self.s**3/(12*(1-0.3**2))
        n=((3*(1-0.3**2))**0.25)/((Rm*self.s)**0.5)

        d11=1/(2*K*n**3)+Rm**2/(self.E*w*self.t)
        d22=1/(K*n)+12*Rm**2/(self.E*w*self.t**3)
        c12=1/(2*K*n**2)
        c22=1/(K*n)

        d02=self.tilt_angle * (d11*d22-c12**2)/(c22*d11-c12**2)
        M_tilt=d02*(self.E*w*self.t**3)/(12*Rm**2)
        delta_Z_gap_incl=-M_tilt*c_m/(w/2+self.b)
        
        log_data(self, M_tilt=M_tilt)
        
        return delta_Z_gap_incl
    
    @cached_property
    def _early_prying_neutralization_shell_force (self):
        '''Increase of the gap closing force due to early prying at the edges.'''
        # Calculate geometric properties                
        Rm= self.R - self.s/2
        c_m=self.central_angle*Rm
        A_tg= c_m *self.t
        I_tg = c_m * self.t**3 / 12
       
        # Calculate the gap stiffness
        alpha_gap=self.gap.angle*180/pi
        f_tot= min(1 + alpha_gap/90 *1.5,2.5)
        k_gap=self._gap_stiffness/f_tot                 #total gap stiffness, without the adjustment factor of 2.2 acc. to [1] eq.26

        #Preload force at which edge contact occurs (31)
        Fv_c=0.5*self.gap.height/( self.b**3/(3*self.E*I_tg) + self.b**2*self.a/(2*self.E*I_tg) + 1.2*self.b/(self.G*A_tg) + 1/(c_m*(k_gap)) )

        #Reduction due to early prying (30)
        delta_Z_gap_c=-max((self.Fv-Fv_c) * ((3*self.a+2*self.b)*self.b**2/(2*(self.a+self.b)**3)),0)
        
        log_data(self, Fv_c=Fv_c, A_tg=A_tg, I_tg=I_tg)
        
        return delta_Z_gap_c
    
    @cached_property
    def _ideal_bolt_force_at_tensile_ULS (self):
        '''Bolt axial force at tensile ULS.'''
        # The bolt is loaded with the ultimate capacity, by definition.
        # If the pretension Fv is too close to the ultimate capacity Fsu, the polynomial
        # function may get too steep, therefore we make sure that Fs2 is at list 125% of Fv.
        return max(self.bolt.ultimate_tensile_capacity(), 1.25*self.bolt_force_at_rest)
    
    @cached_property
    def _ideal_shell_force_at_tensile_ULS (self):
        '''Ideal shell force at tensile ULS.'''
        return self._ideal_bolt_force_at_tensile_ULS * 2

    @cached_property
    def _prying_lever_ratio (self):
        '''Lever ratio A, as defined in [9].'''

        # Ref. [9] uses different symbolts than ref. [1].
        # This getter uses the symbols defined in ref. [9].
        e = self.a
        g = self.b

        # The flange is considered rigid if e <= 1.25*g.
        # In a rigid flange, the pivid point is the edge, therefore e_reduced = e.
        if e/g <= 1.25:
            return (e + g) / e

        # For e > 2.25*g, the model defined in ref. [9] has not been
        # validated. A warning is thrown, but then the model is applied
        # anyways.
        if e/g > 2.25:
            logger.warning("Flange geometry out of validity range for Tobinaga & Ishihara lever ratio formulation: e/g > 2.25.")

        # Coefficient a, expressing the slenderness of the longitudinal
        # cross-section of this flange-segment as tatio between thickness
        # and length.
        a = min(self.t / (e+g), 1.0)
        if a < 0.55 - 0.12 * (e/g):
            # When outside the boundary of validations, throw a warning, but then
            # apply the model anyways.
            logger.warning("Flange geometry out of validity range for Tobinaga & Ishihara lever ratio formulation: a < 0.55 - 0.12 * (e/g).")

        # Evaluate the ratio between distance e (pivit point location for rigid body rotation)
        # and the acctual center of reaction at the prying contact location.
        b = (e/g - 1.25)**0.32 + 0.45
        actionpoint_correction_factor = min(1 - (1 - a**b)**5, 1.0)

        # Distance from the center of reaction at prying contact location, form
        # the center of bolt hole.
        e_reduced = actionpoint_correction_factor * e

        # Lever ratio
        return (e_reduced + g) / e_reduced

    @cached_property
    def _gap_stiffness (self):
        '''Stiffness of the design gap.

        Returns the gap stiffness as a spring constant per unit of flange-segment
        arc length, calculated according to ref.[1], sec. 9.1.
        '''

        # Calculate the shell stiffness
        #Rm = self.R - self.s/2   # radius of the shell midline
        #L_gap = Rm * self.gap.angle
        L_gap = self.R * self.gap.angle
        #k_fac = max(1.8, 1.3 + (8.0e-4 - 1.6e-7 * (Rm*1000)) * (L_gap*1000))    # ref. [1], eq.48
        k_fac = max(1.8, 1.3 + (8.0e-4 - 1.6e-7 * (self.R*1000)) * (L_gap*1000))    # ref. [1], eq.48
        s_avg = (self.s + self.s_ratio * self.s) / 2
        k_shell = self.k_shell or self.E * s_avg / (k_fac * L_gap)                   # ref. [1], eq.47

        # Calculate the flange stiffness
        w = (self.a + self.b)*2      # flange segment length
        A = w * self.t                      # flange segment longitudinal cross-section area
        I = w * self.t**3 / 12              # flange segment longitudinal corss-section second moment of area
        EI = self.E * I
        GA = self.G * A
        L2 = L_gap**2
        k_flange = 384 * EI * GA / (L2 * (GA*L2 + 48*EI))   # ref. [1], eq.49
        
        alpha_gap=self.gap.angle*180/pi
        f_tot= min(1 + alpha_gap/90 *1.5,2.5)
        
        log_data(self, L_gap=L_gap, k_fac=k_fac, k_shell_ini=k_shell, A_cf=A, I_cf=I, k_fl=k_flange, f_tot=f_tot)

        # Total gap stiffness according to ref. [1], eq.53
        return f_tot * (k_shell + k_flange)

    @cached_property
    def _stiffness_correction_factor (self):
        '''Stiffness correction factor (alpha-k).

        This factor modifies the segment force to account for the effect of
        the gap spring, evaluated according to ref. [1], sec. 9.2.2.2.
        '''

        from math import pi

        Rm= self.R - self.s/2
        cm=self.central_angle*Rm

        # Retrieve point 2B
        Z0 = self._ideal_shell_force_at_tensile_ULS
        # Z2B=max(Z0 + self._parallel_gap_neutralization_shell_force,
        #         0.2 * Z0)

        Fs0 = self._ideal_bolt_force_at_tensile_ULS

        # Evaluate the displacement u in the ultimate prying state.
        Cs=self._bolt_axial_stiffness

        u = (Fs0-self.Fv)/(2*Cs)   # (40)

        # Evaluate the segment stiffness
        k_seg = Z0 / (u * cm)
        
        log_data(self, u=u, k_seg=k_seg)
        
        # Return the stiffness correction factor, acc. [1], eq.75
        return min(1 + self._gap_stiffness / k_seg,
                   4 * pi/3 / self.gap.angle)

    @cached_property
    def _polynomial_initial_slope (self):
        '''Initial slope of the Fs(Z) polynomial.

        This slope is calculated according to ref. [1], eq. 80.
        '''

        # Load factor of the tension spring
        p = self._bolt_axial_stiffness / (self._bolt_axial_stiffness + self._flange_axial_stiffness)
        p_max=(self.bolt_force_at_tensile_ULS - self.bolt_force_at_rest) / (self.shell_force_at_tensile_ULS - self.shell_force_at_rest)
        
        # Initial slope correction factor
        #scf = min(0.5 , 0.5*(-self._total_gap_neutralization_shell_force / (0.2 * self.Fv))**2)
        
        #gap closing ratio
        gap_closing_ratio=self._total_gap_neutralization_shell_force/(self.Fv)
        
        # Initial slope
        xi_ini=min(gap_closing_ratio*p*0.5,p_max)*self.gap.shape_factor
        
        return -xi_ini


    # ----------------------------------------------------------------------
    #  DEPRECATED ATTRIBUTES AND METHODS
    #
    #  The following methods are deprecated and kept only for backwards
    #  compatibility
    # ----------------------------------------------------------------------

    @property
    def gap_height (self):
        '''Deprecated. Use `gap.height` instead.'''
        return self.gap.height

    @property
    def gap_angle (self):
        '''Deprecated. Use `gap.angle` instead.'''
        return self.gap.angle

    @property
    def gap_shape_factor (self):
        '''Deprecated. Use `gap.shape_factor` instead.'''
        return self.gap.shape_factor





def bolt_markov_matrix (fseg, flange_markov_matrix, bending_factor=0.0, macro_geometric_factor=1.0, mean_factor=1.0, range_factor=1.0, SMF=1.0):
    '''Evaluates the bolt Markov matrix from the shell Markov matrix.

    The flange bending moment ranges and means are converted into shell pull
    forces acting on the flange segment, and then into minimum and maximum bolt
    stresses through the transfer functions of the flange segment. The bolt
    stress is the sum of the axial stress and of the bending stress scaled by
    `bending_factor`, evaluated on the bolt thread cross-section.

    Args:
        fseg (PolynomialFlangeSegment): The flange segment containing the
            transfer functions. **WARNING:** Currently only works with
            PolynomialFlangeSegments.
        flange_markov_matrix (pyflange.fatigue.MarkovMatrix): The Markov
            matrix of bending moments on the flange.
        bending_factor (float, optional): Factor for the bending portion of the total
            stress range. Defaults to 0.0 (axial stress only).
        macro_geometric_factor (float, optional): Factor for macro geometric influences,
            affecting dead weight, mean, and range values. If omitted, it defaults to 1.0.
        mean_factor (float, optional): Factor for the mean values of the tower's
            bending moments. If omitted, it defaults to 1.0.
        range_factor (float, optional): Factor for the range of the tower's bending
            moments. If omitted, it defaults to 1.0.
        SMF (float, optional): Stress Multiplication Factor to be applied 
            to bolt Markov matrix stress ranges. If omitted, it defaults to 1.0.

    Returns:
        pyflange.fatigue.MarkovMatrix: The bolt's Markov matrix representing
            the stress history. Its cycles and duration are the same as the
            flange Markov matrix.
    '''
    from .fatigue import MarkovMatrix

    #Flange Geometry
    Rm = fseg.R - fseg.s/2
    flange_W = pi/4 * (fseg.R**4 - (fseg.R-fseg.s)**4) / Rm
    shell_A = fseg.s * fseg.central_angle * Rm

    # Bolt Geometry
    bolt_A = fseg.bolt.thread_cross_section.area
    bolt_W = fseg.bolt.thread_cross_section.elastic_section_modulus

    # Shell Markov Matrix
    Z_cycles = flange_markov_matrix.cycles
    Z_mean   = flange_markov_matrix.mean / flange_W * shell_A * mean_factor * macro_geometric_factor
    Z_ranges = flange_markov_matrix.range / flange_W * shell_A * range_factor * macro_geometric_factor
    Z_min = Z_mean - Z_ranges/2 + fseg.Zg * macro_geometric_factor
    Z_max = Z_mean + Z_ranges/2 + fseg.Zg * macro_geometric_factor

    # Bolt ess Markov Matrix
    S_min = fseg.bolt_axial_force(Z_min)/bolt_A + bending_factor * fseg.bolt_bending_moment(Z_min)/bolt_W
    S_max = fseg.bolt_axial_force(Z_max)/bolt_A + bending_factor * fseg.bolt_bending_moment(Z_max)/bolt_W
    return MarkovMatrix(range = SMF * np.abs(S_max - S_min),
                        mean = (S_min + S_max) / 2,
                        cycles = Z_cycles,
                        duration = flange_markov_matrix.duration)



def shell_stiffness (shell_radius, shell_thickness, gap_angle):
    '''Calculates the axial stiffness of a flange-segment shell via interpolation.

    This function interpolates shell stiffness from a dataset of 2160 FEA results.
    Values outside the range covered by the dataset are not extrapolated, and
    `nan` is returned instead.

    Args:
        shell_radius (float): Outer radius of the shell.
        shell_thickness (float): Thickness of the shell.
        gap_angle (float): Angular length of the flange gap in radians.

    Returns:
        float: The interpolated shell stiffness (K_sh), or `nan` if the
            arguments are outside the dataset range.
    '''
    interpolate_shell_stiffness = _load_shell_stiffness_interpolator()
    return interpolate_shell_stiffness(shell_radius, shell_thickness, gap_angle)


@cache
def _load_shell_stiffness_interpolator ():
    # Loads and caches the shell stiffness interpolator.
    # Returns scipy.interpolate.LinearNDInterpolator: The interpolator function.

    from .utils import load_csv_database
    from scipy.interpolate import LinearNDInterpolator
    ssdf = load_csv_database("flangesegments.shell_stiffness", index_col=None)
    return LinearNDInterpolator(list(zip(ssdf['shell_radius'], ssdf['shell_thickness'], ssdf['gap_angle']/180*pi)), ssdf['shell_stiffness'])
